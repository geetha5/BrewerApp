# Brewer

Brewer is an app that help you brew beer nightly and weekly.
Please check the [article](https://medium.com/flawless-app-stories/build-it-test-it-deliver-it-complete-ios-guide-on-continuous-delivery-with-fastlane-and-jenkins-cbe44e996ac5) for more infromation.

## Introduction

![Our strategy](./img.jpeg)

This is our brewing schedule.



