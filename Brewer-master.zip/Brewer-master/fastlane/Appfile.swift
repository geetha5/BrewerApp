var appIdentifier: String { return "[[APP_IDENTIFIER]]" } // The bundle identifier of your app
var appleID: String { return "[[APPLE_ID]]" } // Your Apple email address



// For more information about the Appfile, see:
//     https://docs.fastlane.tools/advanced/#appfile
